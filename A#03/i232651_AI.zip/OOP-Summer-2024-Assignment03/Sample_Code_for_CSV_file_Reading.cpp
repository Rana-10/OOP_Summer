#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;
int main() {
    ifstream inputFile("autos.csv");

    if (!inputFile.is_open()) {
        cout << "Failed to open file!" << endl;
        return 1;
    }
    string line;
    int row = 0;
    while (getline(inputFile, line)) {
        stringstream lineStream(line);
        string cell;
        while (getline(lineStream, cell, ',')) 
		{
        	cout<<cell<<" ";
        }
        cout<<endl;
    }
    inputFile.close();

    return 0;
}

