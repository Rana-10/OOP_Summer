// Assignment 03
// Muhammad Azmat
// 23i-2651
// OOP-B

#include <iostream>
#include <string>
#include <cstring>

using namespace std;

class conversion
{
private:
    string conversionString;
    int base;
    int val;

    int convert_to_base_10(const string &str, int base) const
    {
        int number = 0;
        for (char c : str)
        {
            number = number * base + (c >= '0' && c <= '9' ? c - '0' : c - 'A' + 10);
            // if c is from 0 to 9 (in char) so we convert it into integer by subtracting zero
            // if not a digit, tou we subract 'A' and add 10 to conver into int value
        }
        return number;
    }

    string convert_from_base_10(int number, int base) const
    {
        string answer;
        if (number == 0)
            return "0";
        while (number > 0) // mod div logic
        {
            int remainder = number % base;
            answer += (remainder < 10 ? '0' + remainder : 'A' + remainder - 10);
            number /= base;
        }
        int n = answer.size();
        for (int i = 0; i < n / 2; ++i) // reversing the string
        {
            swap(answer[i], answer[n - i - 1]);
        }
        return answer;
    }

public:
    conversion(string conversionStr, int base)
    {
        conversionString = conversionStr;
        this->base = base;
        if (base > 60 || base < 2)
        {
            cout << "Base entered is not valid brother." << endl;
        }
        val = convert_to_base_10(conversionStr, base);
    }

    conversion operator+(const conversion &other) const
    {

        return conversion(convert_from_base_10(val + other.val, base), base);
    }

    conversion operator-(const conversion &other) const
    {
        return conversion(convert_from_base_10(val - other.val, base), base);
    }

    conversion &operator+=(const conversion &other)
    {
        this->val = this->val + other.val;
        conversionString = convert_from_base_10(val, base);
        return *this;
    }

    conversion &operator-=(const conversion &other)
    {
        this->val = this->val - other.val;
        conversionString = convert_from_base_10(val, base);
        return *this;
    }

    conversion operator*(const conversion &other) const
    {
        return conversion(convert_from_base_10(val * other.val, base), base);
    }

    conversion operator/(const conversion &other) const
    {
        if (other.val == 0)
        {
            cout << "The denominator cannot be zero brother!" << endl;
        }
        else
        {
            return conversion(convert_from_base_10(val / other.val, base), base);
        }
    }

    conversion operator%(const conversion &other) const
    {
        if (other.val == 0)
        {
            cout << "The denominator can't be zero brother!" << endl;
        }
        else
        {
            return conversion(convert_from_base_10(val % other.val, base), base);
        }
    }

    conversion operator|(const conversion &other) const
    {
        return conversion(convert_from_base_10((val | other.val), base), base);
    }

    conversion operator^(const conversion &other) const
    {
        return conversion(convert_from_base_10((val ^ other.val), base), base);
    }

    conversion operator&(const conversion &other) const
    {
        return conversion(convert_from_base_10((val & other.val), base), base);
    }

    conversion operator!() const
    {
        return conversion(convert_from_base_10(~val + 1, base), base);
    }

    conversion operator~() const
    {
        return conversion(convert_from_base_10(~val, base), base);
    }

    conversion operator<<(int shiftAmount) const
    {
        return conversion(convert_from_base_10(val << shiftAmount, base), base);
    }

    conversion operator>>(int shiftAmount) const
    {
        return conversion(convert_from_base_10(val >> shiftAmount, base), base);
    }

    friend istream &operator>>(istream &input, conversion &other)
    {
        input >> other.base;
        input >> other.conversionString;
        other.val = other.convert_to_base_10(other.conversionString, other.base);
        return input;
    }

    friend ostream &operator<<(ostream &output, const conversion &other)
    {
        output << "base " << other.base << " = " << other.conversionString
               << " & base 10 = " << other.val;
        return output;
    }
};



int main()
{
    conversion number_1("110", 2);
    conversion number_2("011", 2);

    cout << "Number 1: " << number_1 << endl;
    cout << "Number 2: " << number_2 << endl;

    conversion sum = number_1 + number_2;
    conversion diff = number_1 - number_2;
    conversion product = number_1 * number_2;
    conversion quotient = number_1 / number_2;
    conversion remainder = number_1 % number_2;
    conversion bitwise_or = number_1 | number_2;
    conversion bitwise_xor = number_1 ^ number_2;
    conversion bitwise_and = number_1 & number_2;
    conversion twos_complement = !number_1;
    conversion ones_complement = ~number_1;
    conversion left_shift = number_1 << 2;
    conversion right_shift = number_1 >> 2;

    cout << "Addition: " << sum << endl;
    cout << "Subtraction: " << diff << endl;
    cout << "Multiplication: " << product << endl;
    cout << "Div: " << quotient << endl;
    cout << "Mod: " << remainder << endl;
    cout << "Bitwise OR: " << bitwise_or << endl;
    cout << "Bitwise XOR: " << bitwise_xor << endl;
    cout << "Bitwise AND: " << bitwise_and << endl;
    cout << "2's Complement of number1: " << twos_complement << endl;
    cout << "1's Complement of number1: " << ones_complement << endl;
    cout << "Left Shft number1 by 2: " << left_shift << endl;
    cout << "Right Shft number1 by 2: " << right_shift << endl;

    conversion example("", 2);
    cout << "Enter a base and a string: ";
    cin >> example;
    cout << "The results are: " << example << endl;

    return 0;
}