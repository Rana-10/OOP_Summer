// Assignment 03
// Muhammad Azmat
// 23i-2651
// OOP-B

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

class Car
{
private:
    string name;
    string date_crawled; // the date ad was first seen
    string seller_type;  // priv or dealer
    string offer_type;
    double price;
    string ab_testing_info;
    string vehicle_type;
    int year_of_regis;
    string gearbox_type; // manual or auto
    int whp;             // hp
    string model;
    int kms_driven;
    int month_of_regis; // how much old car is
    string fuel_type;   // diesel or petrol
    string company_name;
    string damage_not_repaired;
    string ad_creation_date; // the day ad was posted
    int no_of_pics;
    string postal_code;
    string last_seen;

public:
    Car()
    {
        name = "";
        price = 0.0;
        whp = 0;
        model = "";
        year_of_regis = 0;
        kms_driven = 0;
        no_of_pics = 0;
        month_of_regis = 0;
    }

    Car operator+(const Car &other) const
    {
        Car addition;
        addition.price = this->price + other.price;
        addition.whp = this->whp + other.whp;
        addition.kms_driven = this->kms_driven + other.kms_driven;
        addition.no_of_pics = this->no_of_pics + other.no_of_pics;
        addition.year_of_regis = this->year_of_regis + other.year_of_regis;
        return addition;
    }

    Car &operator+=(const Car &other)
    {
        this->price += other.price;
        this->whp += other.whp;
        this->kms_driven += other.kms_driven;
        this->no_of_pics += other.no_of_pics;
        return *this;
    }

    double operator-(const Car &other) const
    {
        Car subtract;
        subtract.price = this->price - other.price;
        return subtract.price;
    }

    Car &operator-=(const Car &other)
    {
        if (this->price > other.price)
        {
            this->price -= other.price;
            this->whp -= other.whp;
            this->kms_driven -= other.kms_driven;
            this->no_of_pics -= other.no_of_pics;
        }
        else
        {
            cout << "Subtraction not possible!" << endl;
        }
        return *this;
    }

    bool operator==(const Car &other) const
    {
        if (this->name == other.name &&
            this->date_crawled == other.date_crawled &&
            this->seller_type == other.seller_type &&
            this->offer_type == other.offer_type &&
            this->price == other.price &&
            this->ab_testing_info == other.ab_testing_info &&
            this->vehicle_type == other.vehicle_type &&
            this->year_of_regis == other.year_of_regis &&
            this->gearbox_type == other.gearbox_type &&
            this->whp == other.whp &&
            this->model == other.model &&
            this->kms_driven == other.kms_driven &&
            this->month_of_regis == other.month_of_regis &&
            this->fuel_type == other.fuel_type &&
            this->company_name == other.company_name &&
            this->damage_not_repaired == other.damage_not_repaired &&
            this->ad_creation_date == other.ad_creation_date &&
            this->no_of_pics == other.no_of_pics &&
            this->postal_code == other.postal_code &&
            this->last_seen == other.last_seen)
        {
            return true;
        }
        else
            return false;
    }

    bool operator>(const Car &other) const
    {
        if (this->price > other.price)
            return true;
        else
            return false;
    }

    bool operator<(const Car &other) const
    {
        if (this->price < other.price)
            return true;
        else
            return false;
    }

    bool operator>=(const Car &other) const
    {
        if (this->price >= other.price)
            return true;
        else
            return false;
    }

    bool operator<=(const Car &other) const
    {
        if (this->price <= other.price)
            return true;
        else
            return false;
    }

    bool operator!=(const Car &other) const
    {
        return !(*this == other);
    }

    friend ostream &operator<<(ostream &output, const Car &car)
    {
        output << "Your Car Name: " << car.name << endl;
        output << "Your Car HP: " << car.whp << endl;
        output << "Your Car Price: " << car.price << endl;
        output << "Your Car Mileage: " << car.kms_driven << endl;
        output << "Your Car Regt. : " << car.year_of_regis << endl;
        return output;
    }

    friend istream &operator>>(istream &inp, Car &car)
    {
        inp >> car.name;
        inp >> car.whp;
        inp >> car.price;
        inp >> car.kms_driven;
        inp >> car.year_of_regis;
        return inp;
    }

    Car operator+() const
    {
        Car output = *this;
        output.price = (+1) * output.price;
        output.whp = (+1) * output.whp;
        output.kms_driven = (+1) * output.kms_driven;
        output.no_of_pics = (+1) * output.no_of_pics;

        return output;
    }

    Car operator-() const
    {
        Car output = *this;
        output.price = (-1) * output.price;
        output.whp = (-1) * output.whp;
        output.kms_driven = (-1) * output.kms_driven;
        output.no_of_pics = (-1) * output.no_of_pics;

        return output;
    }
};

int main()
{
    Car eg1, eg2;

    cout << "Enter the name, hp, price, mileage and regist. for car 1:" << endl;
    cin >> eg1; // name, hp, price, mileage, regst.
    cout << endl;

    cout << "Enter the name, hp, price, mileage and regist. for car 2:" << endl;
    cin >> eg2;
    cout << endl;

    cout << "Car 1 details are as follows:" << endl;
    cout << eg1;
    cout << endl;

    cout << "Car 2 details are as follows:" << endl;
    cout << eg2;
    cout << endl;

    Car eg3 = eg1 + eg2;
    cout << "Car 3 (Car 1 + Car 2) details:" << endl;
    cout << eg3;
    cout << endl;

    eg1 += eg2;
    cout << "Car 1 after += Car 2:" << endl;
    cout << eg1;
    cout << endl;

    double price_diff = eg1 - eg2;
    cout << "Price difference (Car 1 - Car 2): " << price_diff << endl;

    eg1 -= eg2;
    cout << "Car 1 after -= Car 2:" << endl;
    cout << eg1;
    cout << endl;

    if (eg1 == eg2)
        cout << "Car 1 is = to Car 2." << endl;
    else
        cout << "Car 1 is != to Car 2." << endl;

    if (eg1 > eg2)
        cout << "Car 1 is more pricey than Car 2." << endl;
    else if (eg1 < eg2)
        cout << "Car 1 is cheap than Car 2." << endl;

    cout << "Car 1 specifications after applying the unary (+) op:" << endl;
    cout << +eg1;
    cout << endl;

    cout << "Car 1 specs after applying the unary (-) op:" << endl;
    cout << -eg1;
    cout << endl;

    return 0;
}