// Assignment 03
// Muhammad Azmat
// 23i-2651
// OOP-B

#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class Matrix
{
private:
    int rows;
    int cols;
    int **matrixx;

public:
    Matrix()
    {
        rows = 0;
        cols = 0;
        matrixx = nullptr;
    }

    Matrix(int r, int c)
    {
        rows = r;
        cols = c;
        memory_allocation();

        cout << "Enter the elements for your 2D Matrix! " << endl;

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                cin >> matrixx[i][j];
            }
        }
    }

    Matrix(const Matrix &other)
    {
        memory_allocation();
        this->rows = other.rows;
        this->cols = other.cols;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                this->matrixx[i][j] = other.matrixx[i][j];
            }
        }
    }

    void memory_allocation()
    {
        matrixx = new int *[rows];
        for (int i = 0; i < rows; i++)
        {
            matrixx[i] = new int[cols];
        }
    }

    ~Matrix()
    {
        for (int i = 0; i < rows; i++)
        {
            delete[] matrixx[i];
        }
        delete[] matrixx;
        matrixx = nullptr;
        rows = 0;
        cols = 0;
    }

    // Overloaded new and delete operators
    void *operator new(size_t size)
    {
        return ::operator new(size);
    }

    void operator delete(void *pointer)
    {
        return ::operator delete(pointer);
    }

    Matrix operator+(const Matrix &other) const
    {
        Matrix add(rows, cols);
        if (this->rows == other.rows && this->cols == other.cols)
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    add.matrixx[i][j] = this->matrixx[i][j] + other.matrixx[i][j];
                }
            }
        }
        return add;
    }

    Matrix operator-(const Matrix &other) const
    {
        Matrix subt(rows, cols);
        if (this->rows == other.rows && this->cols == other.cols)
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    subt.matrixx[i][j] = this->matrixx[i][j] - other.matrixx[i][j];
                }
            }
        }
        return subt;
    }

    Matrix operator*(const Matrix &other) const
    {
        if (this->cols != other.rows)
        {
            cout << "Matrix multiplication not possible, as column of 1st matrix should be = to row no of 2nd matrix" << endl;
        }
        else
        {
            Matrix mult(rows, other.cols);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    mult.matrixx[i][j] = 0;
                    for (int k = 0; k < other.cols; k++)
                    {
                        mult.matrixx[i][j] += this->matrixx[i][k] * other.matrixx[k][j];
                    }
                }
            }
            return mult;
        }
    }
    Matrix operator*(float scalar) const
    {
        Matrix answer(rows, cols);
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                answer.matrixx[i][j] = scalar * matrixx[i][j];
            }
        }
        return answer;
    }
    Matrix inverse() const
    {
        if (rows != cols)
        {
            cout << "Matrix must be square to find its inverse" << endl;
            cout << "Exiting!! " << endl;
            exit(0);
        }

        Matrix augmented_mat(rows, 2 * cols);

        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < cols; ++j)
            {
                augmented_mat.matrixx[i][j] = matrixx[i][j];
                augmented_mat.matrixx[i][j + cols] = (i == j) ? 1 : 0;
            }
        }

        // Gauss-Jordan Elimination
        for (int i = 0; i < rows; ++i)
        {
            // Find the pivot
            if (augmented_mat.matrixx[i][i] == 0)
            {
                bool swapped = false;
                for (int k = i + 1; k < rows; ++k)
                {
                    if (augmented_mat.matrixx[k][i] != 0)
                    {
                        for (int j = 0; j < 2 * cols; j++) // swapping the rows
                        {
                            swap(augmented_mat.matrixx[i][j], augmented_mat.matrixx[k][j]);
                        }
                        swapped = true;
                        break;
                    }
                }
                if (!swapped)
                {
                    cout << "Matrix is singular and cannot be inverted" << endl;
                }
            }

            // Normalize the pivot row
            float pivot = augmented_mat.matrixx[i][i];
            for (int j = 0; j < 2 * cols; ++j)
            {
                augmented_mat.matrixx[i][j] /= pivot;
            }

            // Eliminate the column entries above and below the pivot
            for (int k = 0; k < rows; ++k)
            {
                if (k != i)
                {
                    float factor = augmented_mat.matrixx[k][i];
                    for (int j = 0; j < 2 * cols; ++j)
                    {
                        augmented_mat.matrixx[k][j] -= factor * augmented_mat.matrixx[i][j];
                    }
                }
            }
        }

        // Extract the inverse from the augmented_mat matrix
        Matrix result(rows, cols);
        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < cols; ++j)
            {
                result.matrixx[i][j] = augmented_mat.matrixx[i][j + cols];
            }
        }

        return result;
    }

    float determinant() const
    {
        if (rows == 1)
        {
            int ans1 = matrixx[0][0];
            return ans1;
        }

        if (rows == 2)
        {
            int ans2 = matrixx[0][0] * matrixx[1][1] - matrixx[0][1] * matrixx[1][0];
            return ans2;
        }
    }

    // Overloaded input/output operators
    friend ostream &operator<<(ostream &os, const Matrix &m)
    {
        for (int i = 0; i < m.rows; i++)
        {
            for (int j = 0; j < m.cols; j++)
            {
                os << m.matrixx[i][j] << " ";
            }
            cout << endl;
        }
        return os;
    }
    friend istream &operator>>(istream &is, Matrix &m)
    {
        for (int i = 0; i < m.rows; i++)
        {
            for (int j = 0; j < m.cols; j++)
            {
                is >> m.matrixx[i][j];
            }
        }
        return is;
    }

    bool operator==(const Matrix &other) const
    {
        if (this->rows != other.rows || this->cols != other.cols)
        {
            cout << "Matrixes are not equal as the order is not same bro" << endl;
            return false;
        }
        else
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (this->matrixx[i][j] != other.matrixx[i][j])
                    {
                        cout << "Elements inside matrix are not same, hence they are not equal!" << endl;
                        return false;
                    }
                }
            }
            return true;
        }
    }

    bool operator!=(const Matrix &other) const
    {
        if (this->rows != other.rows || this->cols != other.cols)
        {
            cout << "Matrixes aren't equal " << endl;
            return true;
        }
        else
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (this->matrixx[i][j] != other.matrixx[i][j])
                    {
                        cout << "Elements inside matrix aren't same, hence they are not equal!" << endl;
                        return true;
                    }
                }
            }
            return false;
        }
    }

    int &operator()(int r, int c)
    {
        if (r >= rows || r < 0 || c >= cols || c < 0)
        {
            cout << "Invalid rows cols entered!" << endl;
        }
        return matrixx[r][c];
    }

    Matrix operator-() const
    {
        Matrix negative_mat(rows, cols);
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                negative_mat.matrixx[i][j] = (-1) * matrixx[i][j];
            }
        }
    }

    Matrix transpose() const
    {
        Matrix transp(cols, rows);
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                transp.matrixx[j][i] = matrixx[i][j];
            }
        }
        return transp;
    }

    // float *eigenvalues() const;

    void saveToFile(const string &filename) const
    {
        ofstream output(filename);
        // to display
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                output << matrixx[i][j] << " ";
            }
            output << endl;
        }

        output.close();
    }

    void loadFromFile(const string &filename)
    {
        ifstream read(filename);
        read >> rows;
        read >> cols;
        matrixx = nullptr;
        memory_allocation();
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                read >> matrixx[i][j];
            }
        }

        read.close();
    }
};

int main()
{

    return 0;
}