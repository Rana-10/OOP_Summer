#include <iostream>
#include <string>
using namespace std;
class Line
{
private:
    char *words;
    const int max_alphabets = 40;
    string txt;

public:
    Line()
    {
        words = new char[40];
    }

    Line(const Line &other)
    {
        txt = other.txt;
        if (txt.length() > max_alphabets)
        {
            cout << "The line you entered exceeds the maximum alphabets limit dear!" << endl;
        }
    }

    Line(const char *text)
    {
        txt = text;
    }

    void add_text(const string &str)
    {
        if (txt.length() + str.length() < max_alphabets)
        {
            txt = txt + str;
        }
        else
        {
            cout << "You are breaking the rules, i.e. exceeding 40 alphabets." << endl;
        }
    }

    ~Line()
    {
        delete[] words;
    }

    Line &operator=(const Line &other)
    {
        if (this != &other)
        {
            txt = other.txt;
        }
        return *this;
    }

    const char *getText() const
    {
        return txt.c_str();
    }

    void setText(const char *newText)
    {
        txt = newText;
    }

    friend ostream &operator<<(ostream &os, const Line &line)
    {
        os << line.getText();
        return os;
    }
};

class Page
{

private:
    const int max_lines = 20;
    Line *liness;
    int current_linee;

public:
    Page()
    {
        liness = new Line[max_lines];
        current_linee = 0;
    }

    Page(const Page &other)
    {
        liness = new Line[max_lines];
        for (int i = 0; i < max_lines; i++)
        {
            liness[i] = other.liness[i];
        }
    }

    Page &operator=(const Page &other)
    {
        if (this == &other)
        {
            return *this;
        }
        else
        {
            delete[] liness;
            liness = new Line[max_lines];
            for (int i = 0; i < max_lines; i++)
            {
                liness[i] = other.liness[i];
            }
            current_linee = other.current_linee;
        }
        return *this;
    }

    ~Page()
    {
        delete[] liness;
    }

    Page &operator+=(const char *text)
    {
        if (current_linee < max_lines)
        {
            liness[current_linee].add_text(text);
            current_linee++;
        }
        else
        {
            cout << "Dear User! you cannot add any more text. Follow the guidelines!" << endl;
        }
        return *this;
    }

    Page &operator+=(const Line &line)
    {
        if (current_linee < max_lines)
        {
            liness[current_linee] = line;
            current_linee++;
        }
        else
        {
            cout << "Dear User! you cannot add any more lines. Follow the guidelines!" << endl;
        }
        return *this;
    }

    Line &operator[](int index)
    {
        if (index >= max_lines || index < 0)
        {
            cout << "You are entering an invalid index dear" << endl;
        }
        return liness[index];
    }

    friend ostream &operator<<(ostream &os, const Page &page)
    {
        for (int i = 0; i < page.current_linee; i++)
        {
            os << "Lines:" << page.liness[i] << endl;
        }
        return os;
    }
};

class Section
{
private:
    Page *pages;
    int size;
    int total_pages;
    int current_page;

public:
    Section()
    {
        total_pages = 0;
        size = 1;
        pages = new Page[size];
        current_page = 0;
    }

    Section(const Section &other)
    {
        total_pages = other.total_pages;
        size = other.size;
        for (int i = 0; i < size; i++)
        {
            pages[i] = other.pages[i];
        }
    }
    Section &operator=(const Section &other)
    {
        if (this != &other)
        {
            size = other.size;
            total_pages = other.total_pages;
            pages = new Page[size];
            for (int i = 0; i < size; i++)
            {
                this->pages[i] = other.pages[i];
            }
        }
        return *this;
    }

    friend ostream &operator<<(ostream &os, const Section &section)
    {
        for (int i = 0; i < section.current_page; i++)
        {
            os << "Page:" << endl;
            os << section.pages[i] << endl;
        }
        return os;
    }

    ~Section()
    {
        delete[] pages;
    }

    Section &operator+=(const Page &page)
    {
        if (current_page < total_pages)
        {
            pages[current_page] = page;
            current_page++;
        }
        else
        {
            cout << "Dear User! you cannot add any more sections. Follow the guidelines!" << endl;
        }
        return *this;
    }

    Page &operator[](int index)
    {
        if (index >= size || size < 0)
        {
            cout << "You are not entering a valid index bro!" << endl;
        }
        else
        {
            return pages[index];
        }
    }
};

class Article
{
private:
    Section *sections;
    int total_no_of_sections;
    int arr_size;
    int current_section;

public:
    Article()
    {
        const int total_no_of_sections = 5;
        arr_size = 1;
        sections = new Section[arr_size];
        current_section = 0;
    }

    Article(const Article &other)
    {
        this->total_no_of_sections = other.total_no_of_sections;
        this->arr_size = other.arr_size;
        sections = new Section[arr_size];
        for (int i = 0; i < arr_size; i++)
        {
            this->sections[i] = other.sections[i];
        }
        current_section = other.current_section;
    }
    Article &operator=(const Article &other)
    {
        if (this != &other)
        {
            delete[] sections;
            this->total_no_of_sections = other.total_no_of_sections;
            this->arr_size = other.arr_size;
            for (int i = 0; i < arr_size; i++)
            {
                sections[i] = other.sections[i];
            }
            current_section = other.current_section;
        }
        return *this;
    }
    ~Article()
    {
        delete[] sections;
    }

    Article &operator+=(const char *text)
    {
        if (current_section < total_no_of_sections)
        {
            sections[current_section][0] += text;
        }
        else
        {
            cout << "You can't add any more txt brother!" << endl;
        }
        return *this;
    }

    Article &operator+=(const Line &line)
    {
        if (current_section < total_no_of_sections)
        {
            sections[current_section][0] += line;
        }
        else
        {
            cout << "You can't add any more lines brother!" << endl;
        }
        return *this;
    }

    Article &operator+=(const Page &page)
    {
        if (current_section < total_no_of_sections)
        {
            sections[current_section] += page;
        }
        else
        {
            cout << "You can't add any more pages brother!" << endl;
        }
        return *this;
    }

    Article &operator+=(const Section &section)
    {
        if (current_section < total_no_of_sections)
        {
            sections[current_section] = section;
            current_section++;
        }
        else
        {
            cout << "You can't add any more sections brother!" << endl;
        }
        return *this;
    }
    Section &operator[](int index)
    {
        if (index >= current_section || index < 0)
        {
            cout << "Dear User, You are entering an invalid index!" << endl;
        }
        return sections[index];
    }

    // Page &operator[](int sectionIndex, int pageIndex);                // Access specific page
    // Line &operator[](int sectionIndex, int pageIndex, int lineIndex); // Access specific line
    Article operator+(const Article &other) const // Concatenate two articles
    {
        Article answer;
        for (int i = 0; i < this->current_section; i++)
        {
            answer += this->sections[i];
        }
        for (int i = 0; i < other.current_section; i++)
        {
            answer += other.sections[i];
        }
        return answer;
    }

    friend ostream &operator<<(ostream &os, const Article &article)
    {
        for (int i = 0; i < article.current_section; i++)
        {
            os << "Section:" << endl;
            os << article.sections[i] << endl;
        }
        return os;
    }
};

int main()
{
    Page p1, p2, p3, p4;
    // Add text to pages
    p1 += "The quick brown fox jumps over the lazy dog. This pangram contains every letter of the alphabet, making it a popular sentence for typing practice.";
    p2 += "To be, or not to be, that is the question. Whether 'tis nobler in the mind to suffer the slings and arrows of outrageous fortune.";
    p3 += "All the world's a stage, and all the men and women merely players. They have their exits and their entrances.";
    p4 += "In the beginning, the universe was created. This has made a lot of people very angry and been widely regarded as a bad move.";
    // Create a section and add pages to it
    Section section1;
    section1 += p1;
    section1 += p2;
    section1 += p3;
    // Add the fourth page to the first section
    section1 += p4;
    // Create an article and add sections to it
    Article article;
    article += section1;
    // Create another section with additional pages
    Section section2;
    Page p5, p6;
    p5 += "We hold these truths to be self-evident, that all men are created equal, that they are endowed by their Creator with certain unalienable Rights.";
    p6 += "I have a dream that one day this nation will rise up and live out the true meaning of its creed : 'We hold these truths to be self-evident, that all men are created equal.' ";
    section2 += p5;
    section2 += p6;
    // Add the second section to the article
    article += section2;
    //     // Edit a specific line on a specific page in a specific section
    //     article[1][1] = "This is a new line added to the first page of the second section.";
}