#include <iostream>
#include <string>
using namespace std;
// course information
struct Course
{
    string crName;
    string students[6];
    int studentCount;
};

class EnrollmentMap
{
    Course courses[100];
    int count;

public:
    EnrollmentMap()
    {
        count = 0;
    }

    EnrollmentMap(const EnrollmentMap &other)
    {
        count = other.count;
        for (int i = 0; i < count; ++i)
        {
            courses[i] = other.courses[i];
        }
    }

    Course *find_course(const string &crName)
    {
        for (int i = 0; i < count; ++i)
        {
            if (courses[i].crName == crName)
            {
                return &courses[i];
            }
        }
        return nullptr;
    }
    // assingmnet operator same as copy constrcutor
    EnrollmentMap &operator=(const EnrollmentMap &other)
    {

        count = other.count;
        for (int i = 0; i < count; ++i)
        {
            courses[i] = other.courses[i];
        }

        return *this;
    }

    string &operator[](const string &crName)
    {
        Course *course = find_course(crName);
        if (!course && count < 100)
        {
            courses[count].crName = crName;
            courses[count].studentCount = 0;
            course = &courses[count];
            ++count;
        }
        if (course && course->studentCount < 6)
        {
            return course->students[course->studentCount++];
        }
    }

    EnrollmentMap &operator+=(const string &courseAndStudent)
    {
        string crName;
        string studentName;
        bool foundComma = false;

        for (int i = 0; i < courseAndStudent.size(); ++i)
        {
            if (courseAndStudent[i] == ',')
            {
                crName = courseAndStudent.substr(0, i);
                studentName = courseAndStudent.substr(i + 1);
                foundComma = true;
                break;
            }
        }

        if (foundComma)
        {
            Course *course = find_course(crName);
            if (!course && count < 100)
            {
                courses[count].crName = crName;
                courses[count].studentCount = 0;
                course = &courses[count];
                ++count;
            }

            if (course && course->studentCount < 6)
            {
                course->students[course->studentCount++] = studentName;
            }
            else
            {
                cout << "Course " << crName << " is full or does not exist." << endl;
            }
        }

        return *this;
    }

    EnrollmentMap &operator-=(const string &courseAndStudent)
    {
        string crName;
        string studentName;
        bool foundComma = false;

        for (int i = 0; i < courseAndStudent.size(); ++i)
        {
            if (courseAndStudent[i] == ',')
            {
                crName = courseAndStudent.substr(0, i);
                studentName = courseAndStudent.substr(i + 1);
                foundComma = true;
                break;
            }
        }

        if (foundComma)
        {
            Course *course = find_course(crName);
            if (course)
            {
                bool foundStudent = false;
                for (int i = 0; i < course->studentCount; ++i)
                {
                    if (course->students[i] == studentName)
                    {
                        for (int j = i; j < course->studentCount - 1; ++j)
                        {
                            course->students[j] = course->students[j + 1];
                        }
                        --course->studentCount;
                        foundStudent = true;
                        break;
                    }
                }

                if (!foundStudent)
                {
                    cout << "Student " << studentName << " not found in course " << crName << endl;
                }
            }
        }

        return *this;
    }

    EnrollmentMap operator+(const EnrollmentMap &other)
    {
        EnrollmentMap result = *this;

        for (int i = 0; i < other.count; ++i)
        {
            const Course &otherCourse = other.courses[i];
            for (int j = 0; j < otherCourse.studentCount; ++j)
            {
                result += (otherCourse.crName + "," + otherCourse.students[j]);
            }
        }

        return result;
    }

    string toString()
    {
        string result;
        for (int i = 0; i < count; ++i)
        {
            result += courses[i].crName + ": ";
            for (int j = 0; j < courses[i].studentCount; ++j)
            {
                result += courses[i].students[j];
                if (j < courses[i].studentCount - 1)
                {
                    result += ", ";
                }
            }
            result += "\n";
        }
        return result;
    }

    ~EnrollmentMap()
    {
    }
};

int main()
{
    EnrollmentMap enrollments1, enrollments2, mergedEnrollments;

    // Adding students to courses
    enrollments1["Math 101"] = "Alice Smith";
    enrollments1["History 201"] = "Bob Johnson";
    enrollments2["Physics 101"] = "Charlie Brown";

    // Adding more students to existing courses
    enrollments1 += "Math 101,David Jones";
    enrollments1 += "Math 101,Eva Green";
    enrollments2 += "Physics 101,Frank White";
    enrollments2 += "Physics 101,Grace Black";
    enrollments2 += "Physics 101,Hank Blue";
    enrollments2 += "Physics 101,Ivy Red";

    // Adding a new course with students
    enrollments2 += "Chemistry 101,Jack Gold";
    enrollments2 += "Chemistry 101,Karen Silver";
    enrollments2 += "Chemistry 101,Leo Bronze";
    enrollments2 += "Chemistry 101,Mia Copper";

    // Merging two enrollment maps
    mergedEnrollments = enrollments1 + enrollments2;
    cout << "Merged Enrollments: " << mergedEnrollments.toString() << endl;

    // Removing a student from a course
    enrollments1 -= "Math 101,David Jones";
    cout << "Updated Enrollments: " << enrollments1.toString() << endl;

    return 0;
}
