#include <iostream>
#include <string>

using namespace std;
class Rational
{
private:
    int numerator;
    int denominator;

public:
    Rational()
    {
        numerator = 0;
        denominator = 1;
        // cout << "The default fraction is: " << numerator << "/" << denominator << endl;
    }

    Rational(int num, int denom)
    {
        if (denom == 0)
        {
            cout << "The Denominator cannot be zero as then, the answer will be infinity" << endl;
            exit(0);
        }
        else
        {
            numerator = num;
            denominator = denom;
            cout << "The parametrised fraction is: " << numerator << "/" << denominator << endl;
        }
    }

    Rational(const Rational &other)
    {
        this->numerator = other.numerator;
        this->denominator = other.denominator;
    }

    ~Rational()
    {
        numerator = 0;
        denominator = 0;
    }

    Rational operator+(const Rational &other) const
    {
        Rational add;
        add.numerator = (this->numerator * other.denominator + this->denominator * other.numerator);
        add.denominator = (this->denominator * other.denominator);
        return add;
    }

    Rational operator-(const Rational &other) const
    {
        Rational subt;
        subt.numerator = (this->numerator * other.denominator - this->denominator * other.numerator);
        subt.denominator = this->denominator * other.denominator;
        return subt;
    }

    Rational operator*(const Rational &other) const
    {
        Rational mult;
        mult.numerator = this->numerator * other.numerator;
        mult.denominator = this->denominator * other.denominator;
        return mult;
    }

    Rational operator/(const Rational &other) const
    {
        Rational div;
        div.numerator = this->numerator * other.denominator;
        div.denominator = this->denominator * other.numerator;
        return div;
    }

    bool operator==(const Rational &other) const
    {
        if (this->numerator == other.numerator && this->denominator == other.denominator)
            return true;
        else
            return false;
    }

    bool operator!=(const Rational &other) const
    {
        if (this->numerator != other.numerator || this->denominator != other.denominator)
            return true;
        else
            return false;
    }

    friend ostream &operator<<(ostream &output, const Rational &rational)
    {
        output << "The numerator is: " << rational.numerator << endl;
        output << "The denominator is: " << rational.denominator << endl;
        output << "The fraction is: " << rational.numerator << "/" << rational.denominator << endl;
        return output;
    }

    friend istream &operator>>(istream &input, Rational &rational)
    {
        cout << "Enter the value of numerator! " << endl;
        input >> rational.numerator;
        cout << "Enter the value of denominator! " << endl;
        input >> rational.denominator;
        return input;
    }

    void display()
    {
        cout << "The fraction is: " << numerator << "/" << denominator << endl;
    }
};

int main()
{
    Rational r1(1, 2);
    Rational r2(1, 3);

    Rational r3 = r1 + r2;
    r3.display();

    Rational r4 = r1 - r2;
    r4.display();

    Rational r5 = r1 * r2;
    r5.display();

    Rational r6 = r1 / r2;
    r6.display();

    cout << (r1 == r2) << endl;
    cout << (r1 != r2) << endl;

    return 0;
}
