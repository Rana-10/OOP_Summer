// Assignment 03
// Muhammad Azmat
// 23i-2651
// OOP-B

#include <iostream>
#include <string>

using namespace std;

class DynamicArray
{
private:
    int *products_array;
    int size;

public:
    DynamicArray(int sizee)
    {
        if (sizee < 0)
        {
            cout << "You cannot make an array which has a size less than 0!" << endl;
            exit(0);
        }
        size = sizee;
        products_array = new int[size];
    }

    DynamicArray(const DynamicArray &other)
    {
        this->size = other.size;
        products_array = new int[size];
        for (int i = 0; i < size; i++)
        {
            this->products_array[i] = other.products_array[i];
        }
    }
    ~DynamicArray()
    {
        delete[] products_array;
    }

    int &operator[](int index)
    {
        if (index >= size || index < 0)
        {
            cout << "The index you are entering is invalid dear!" << endl;
            cout << "Exiting the program" << endl;
            exit(0);
        }

        return products_array[index];
    }

    const int &operator[](int index) const
    {
        if (index >= size || index < 0)
        {
            cout << "You're entering invalid index.. " << endl;
            exit(0);
        }

        return products_array[index];
    }

    DynamicArray &operator=(const DynamicArray &other)
    {
        if (this == &other) // if both arrays are already equal
        {
            return *this;
        }
        delete[] products_array;

        size = other.size;
        products_array = new int[size];
        for (int i = 0; i < size; ++i)
        {
            products_array[i] = other.products_array[i];
        }
        return *this;
    }

    // move operation (this is transfer of ownership not copying)
    DynamicArray &operator=(DynamicArray &&other) // && means transfer of resources from one obj to another without unnecessary copying
    {
        if (this != &other)
        {
            delete[] products_array; // pehle abhi waley resources clean kro

            products_array = other.products_array; // transfer ownership to him
            size = other.size;

            other.products_array = nullptr; // job done, goodbye
            other.size = 0;
        }
        return *this;
    }

    DynamicArray &operator+=(const DynamicArray &other)
    {
        if (this->size == other.size)
        {
            for (int i = 0; i < size; i++)
            {
                this->products_array[i] = this->products_array[i] + other.products_array[i];
            }
        }
        else
        {
            cout << "The two arrays are not of same size, so addition is not possible!" << endl;
        }
    }

    DynamicArray operator+(const DynamicArray &other) const
    {
        if (size == other.size)
        {
            DynamicArray result(size);
            for (int i = 0; i < size; i++)
            {
                result.products_array[i] = this->products_array[i] + other.products_array[i];
            }
            return result;
        }
        else
        {
            cout << "The two arrays must be of the same length bro" << endl;
            cout << "Exiting" << endl;
            exit(0);
        }
    }

    friend ostream &operator<<(ostream &os, const DynamicArray &arr)
    {
        for (int i = 0; i < arr.size; i++)
        {
            os << arr.products_array[i] << " ";
        }
        return os;
    }

    int size_func() const
    {
        int count = 0;
        for (int i = 0; i < size; i++)
        {
            ++count;
        }
        return count;
    }
};

int main()
{

    DynamicArray inventory1(5); // Create a dynamic array with 5 products
    DynamicArray inventory2(5); // Create another dynamic array with 5 product quantities
    // Initialize the inventories
    for (int i = 0; i < 5; ++i)
    {
        inventory1[i] = i * 10; // inventory1: {0, 10, 20, 30, 40}
        inventory2[i] = i * 5;  // inventory2: {0, 5, 10, 15, 20}
    }

    // Perform element-wise addition
    inventory1 += inventory2; // inventory1: {0, 15, 30, 45, 60}

    // Create a new inventory by adding two inventories
    DynamicArray totalInventory = inventory1 + inventory2; // totalInventory: {0, 20, 40, 60, 80}

    // Output the contents of the total inventory
    cout << totalInventory << endl;

    // Get the size of the inventory
    cout << "Total products: " << totalInventory.size_func() << endl;

    return 0;
}